
export interface Department {
  id: number;
  name: string;
  icon: React.ReactNode;
}

export interface Product {
  id: number;
  name: string;
  price: number;
  imageUrl: string;
  departmentId: number;
  description: string;
}
