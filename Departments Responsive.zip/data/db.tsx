
import type { Product, Department } from '../types';
import { ElectronicsIcon, ClothingIcon, HomeGoodsIcon, BooksIcon } from '../components/icons';
import React from 'react';

export const departments: Department[] = [
  { id: 1, name: 'Electronics', icon: <ElectronicsIcon className="w-5 h-5" /> },
  { id: 2, name: 'Apparel', icon: <ClothingIcon className="w-5 h-5" /> },
  { id: 3, name: 'Home Goods', icon: <HomeGoodsIcon className="w-5 h-5" /> },
  { id: 4, name: 'Books', icon: <BooksIcon className="w-5 h-5" /> },
];

export const products: Product[] = [
  {
    id: 1,
    name: 'Wireless Noise-Cancelling Headphones',
    price: 349.99,
    imageUrl: 'https://picsum.photos/seed/tech1/400/400',
    departmentId: 1,
    description: 'Immerse yourself in sound with these premium noise-cancelling headphones.'
  },
  {
    id: 2,
    name: 'Smartwatch Series 8',
    price: 399.00,
    imageUrl: 'https://picsum.photos/seed/tech2/400/400',
    departmentId: 1,
    description: 'Track your fitness, stay connected, and monitor your health from your wrist.'
  },
  {
    id: 3,
    name: '4K Ultra HD Smart TV',
    price: 799.99,
    imageUrl: 'https://picsum.photos/seed/tech3/400/400',
    departmentId: 1,
    description: 'Experience breathtaking clarity and vibrant colors with this 55-inch 4K TV.'
  },
  {
    id: 4,
    name: 'Portable Bluetooth Speaker',
    price: 89.95,
    imageUrl: 'https://picsum.photos/seed/tech4/400/400',
    departmentId: 1,
    description: 'Take your music anywhere with this rugged, waterproof Bluetooth speaker.'
  },
  {
    id: 5,
    name: 'Classic Denim Jacket',
    price: 79.50,
    imageUrl: 'https://picsum.photos/seed/apparel1/400/400',
    departmentId: 2,
    description: 'A timeless denim jacket that completes any casual look.'
  },
  {
    id: 6,
    name: 'Performance Running Shoes',
    price: 129.99,
    imageUrl: 'https://picsum.photos/seed/apparel2/400/400',
    departmentId: 2,
    description: 'Lightweight and responsive shoes designed for your daily run.'
  },
  {
    id: 7,
    name: 'Merino Wool Sweater',
    price: 99.00,
    imageUrl: 'https://picsum.photos/seed/apparel3/400/400',
    departmentId: 2,
    description: 'Stay warm and stylish with this soft, breathable merino wool sweater.'
  },
  {
    id: 8,
    name: 'Leather Crossbody Bag',
    price: 149.00,
    imageUrl: 'https://picsum.photos/seed/apparel4/400/400',
    departmentId: 2,
    description: 'A versatile and elegant leather bag for your everyday essentials.'
  },
  {
    id: 9,
    name: 'Modern Accent Chair',
    price: 299.00,
    imageUrl: 'https://picsum.photos/seed/home1/400/400',
    departmentId: 3,
    description: 'Add a touch of mid-century modern style to your living room.'
  },
  {
    id: 10,
    name: 'Dutch Oven',
    price: 150.00,
    imageUrl: 'https://picsum.photos/seed/home2/400/400',
    departmentId: 3,
    description: 'A versatile cast-iron dutch oven perfect for stews, bread, and more.'
  },
  {
    id: 11,
    name: 'Linen Duvet Cover Set',
    price: 180.00,
    imageUrl: 'https://picsum.photos/seed/home3/400/400',
    departmentId: 3,
    description: 'Experience ultimate comfort with this soft, breathable linen bedding.'
  },
  {
    id: 12,
    name: 'Espresso Machine',
    price: 599.99,
    imageUrl: 'https://picsum.photos/seed/home4/400/400',
    departmentId: 3,
    description: 'Become your own barista with this semi-automatic espresso machine.'
  },
  {
    id: 13,
    name: 'The Midnight Library',
    price: 15.99,
    imageUrl: 'https://picsum.photos/seed/book1/400/400',
    departmentId: 4,
    description: 'A captivating novel about life, death, and the choices we make.'
  },
  {
    id: 14,
    name: 'Sapiens: A Brief History of Humankind',
    price: 22.00,
    imageUrl: 'https://picsum.photos/seed/book2/400/400',
    departmentId: 4,
    description: 'A groundbreaking book that explores the history of our species.'
  },
  {
    id: 15,
    name: 'Atomic Habits',
    price: 18.50,
    imageUrl: 'https://picsum.photos/seed/book3/400/400',
    departmentId: 4,
    description: 'An easy & proven way to build good habits & break bad ones.'
  },
  {
    id: 16,
    name: 'The Vanishing Half',
    price: 16.20,
    imageUrl: 'https://picsum.photos/seed/book4/400/400',
    departmentId: 4,
    description: 'A stunning novel about twin sisters, inseparable as children, who choose to live in two very different worlds.'
  },
];
