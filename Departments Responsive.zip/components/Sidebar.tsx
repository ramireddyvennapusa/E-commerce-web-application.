
import React from 'react';
import type { Department } from '../types';

interface SidebarProps {
  departments: Department[];
  selectedDepartmentId: number | null;
  onSelectDepartment: (id: number | null) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ departments, selectedDepartmentId, onSelectDepartment }) => {
  const baseItemClass = "flex items-center px-4 py-3 text-gray-700 dark:text-gray-200 rounded-lg cursor-pointer transition-colors duration-200";
  const hoverClass = "hover:bg-gray-200 dark:hover:bg-gray-700";
  const activeClass = "bg-primary-500 text-white dark:bg-primary-600";
  const inactiveClass = "hover:bg-gray-100 dark:hover:bg-gray-700";

  return (
    <aside className="w-64 flex-shrink-0 bg-white dark:bg-gray-800 p-4 rounded-xl shadow-lg">
      <h2 className="text-xl font-bold mb-6 text-gray-900 dark:text-white px-2">Departments</h2>
      <nav>
        <ul>
          <li>
            <a
              onClick={() => onSelectDepartment(null)}
              className={`${baseItemClass} ${selectedDepartmentId === null ? activeClass : inactiveClass}`}
            >
              <span className="font-semibold">All Products</span>
            </a>
          </li>
          {departments.map((dept) => (
            <li key={dept.id}>
              <a
                onClick={() => onSelectDepartment(dept.id)}
                className={`${baseItemClass} ${selectedDepartmentId === dept.id ? activeClass : inactiveClass}`}
              >
                <span className="mr-3">{dept.icon}</span>
                <span className="font-medium">{dept.name}</span>
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
