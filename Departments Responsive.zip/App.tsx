
import React, { useState, useEffect, useMemo } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import ProductGrid from './components/ProductGrid';
import type { Product, Department } from './types';
import { products as dbProducts, departments as dbDepartments } from './data/db';

const App: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [selectedDepartmentId, setSelectedDepartmentId] = useState<number | null>(null);

  useEffect(() => {
    // Simulate fetching data from a database/API
    setProducts(dbProducts);
    setDepartments(dbDepartments);
  }, []);

  const filteredProducts = useMemo(() => {
    if (selectedDepartmentId === null) {
      return products;
    }
    return products.filter(
      (product) => product.departmentId === selectedDepartmentId
    );
  }, [products, selectedDepartmentId]);

  const handleSelectDepartment = (id: number | null) => {
    setSelectedDepartmentId(id);
  };

  const currentDepartmentName = useMemo(() => {
    if (selectedDepartmentId === null) {
      return "All Products";
    }
    return departments.find(d => d.id === selectedDepartmentId)?.name || "Products";
  }, [selectedDepartmentId, departments]);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 font-sans">
      <Header />
      <main className="max-w-screen-2xl mx-auto p-4 sm:p-6 lg:p-8">
        <div className="flex flex-col md:flex-row md:space-x-8">
          <div className="w-full md:w-64 mb-8 md:mb-0 md:sticky md:top-24 self-start">
             <Sidebar
              departments={departments}
              selectedDepartmentId={selectedDepartmentId}
              onSelectDepartment={handleSelectDepartment}
            />
          </div>
          
          <div className="flex-1">
             <div className="mb-6">
                <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white">{currentDepartmentName}</h2>
                <p className="mt-1 text-md text-gray-500 dark:text-gray-400">
                    Showing {filteredProducts.length} {filteredProducts.length === 1 ? 'result' : 'results'}
                </p>
            </div>
            <ProductGrid products={filteredProducts} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
