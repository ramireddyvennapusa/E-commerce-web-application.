import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Package } from 'lucide-react';

const Navigation = () => {
  const location = useLocation();

  const isActive = (path) => {
    if (path === '/' && location.pathname === '/') return true;
    if (path !== '/' && location.pathname.startsWith(path)) return true;
    return false;
  };

  const navLinkClass = (path) => `
    flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200
    ${isActive(path) 
      ? 'bg-blue-100 text-blue-700 font-medium' 
      : 'text-gray-600 hover:text-blue-600 hover:bg-gray-50'
    }
  `;

  return (
    <nav className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Package className="h-8 w-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-900">ProductHub</span>
            </Link>
          </div>
          
          <div className="flex space-x-1">
            <Link to="/" className={navLinkClass('/')}>
              <Home className="h-4 w-4" />
              <span>Home</span>
            </Link>
            <Link to="/products" className={navLinkClass('/products')}>
              <Package className="h-4 w-4" />
              <span>Products</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;