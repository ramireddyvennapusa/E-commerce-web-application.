const API_BASE_URL = 'http://127.0.0.1:5000';

// Generic API call function with error handling
const apiCall = async (endpoint) => {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    return { data, error: null };
  } catch (error) {
    console.error('API call failed:', error);
    return { 
      data: null, 
      error: error.message || 'An unexpected error occurred' 
    };
  }
};

// Fetch paginated products with optional category filter
export const fetchProducts = async (page = 1, limit = 20, category = '') => {
  let endpoint = `/products?page=${page}&limit=${limit}`;
  if (category) {
    endpoint += `&category=${encodeURIComponent(category)}`;
  }
  return apiCall(endpoint);
};

// Fetch single product by ID
export const fetchProductById = async (id) => {
  return apiCall(`/products/${id}`);
};

// Get unique categories for search filter
export const fetchCategories = async () => {
  const { data, error } = await apiCall('/products?page=1&limit=1000');
  
  if (error) {
    return { data: [], error };
  }
  
  const products = data?.products || [];
  const categories = [...new Set(products.map(product => product.category))].filter(Boolean);
  
  return { data: categories, error: null };
};