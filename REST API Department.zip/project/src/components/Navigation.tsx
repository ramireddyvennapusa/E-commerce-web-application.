import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Package, ChevronDown } from 'lucide-react';
import { fetchDepartments } from '../utils/api';

const Navigation = () => {
  const location = useLocation();
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showDepartments, setShowDepartments] = useState(false);

  useEffect(() => {
    const loadDepartments = async () => {
      const { data, error } = await fetchDepartments();
      if (!error && data) {
        setDepartments(data);
      }
      setLoading(false);
    };

    loadDepartments();
  }, []);
  const isActive = (path) => {
    if (path === '/' && location.pathname === '/') return true;
    if (path !== '/' && location.pathname.startsWith(path)) return true;
    return false;
  };

  const isDepartmentActive = () => {
    return location.pathname.startsWith('/departments/');
  };
  const navLinkClass = (path) => `
    flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200
    ${isActive(path) 
      ? 'bg-blue-100 text-blue-700 font-medium' 
      : 'text-gray-600 hover:text-blue-600 hover:bg-gray-50'
    }
  `;

  const departmentNavClass = `
    flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 relative
    ${isDepartmentActive() 
      ? 'bg-blue-100 text-blue-700 font-medium' 
      : 'text-gray-600 hover:text-blue-600 hover:bg-gray-50'
    }
  `;
  return (
    <nav className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Package className="h-8 w-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-900">ProductHub</span>
            </Link>
          </div>
          
          <div className="flex space-x-1 relative">
            <Link to="/" className={navLinkClass('/')}>
              <Home className="h-4 w-4" />
              <span>Home</span>
            </Link>
            <Link to="/products" className={navLinkClass('/products')}>
              <Package className="h-4 w-4" />
              <span>Products</span>
            </Link>
            
            {/* Departments Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowDepartments(!showDepartments)}
                className={departmentNavClass}
                disabled={loading}
              >
                <Package className="h-4 w-4" />
                <span>Departments</span>
                <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${showDepartments ? 'rotate-180' : ''}`} />
              </button>
              
              {showDepartments && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                  <Link
                    to="/products"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-blue-600 transition-colors duration-200"
                    onClick={() => setShowDepartments(false)}
                  >
                    All Products
                  </Link>
                  <div className="border-t border-gray-100 my-1"></div>
                  {loading ? (
                    <div className="px-4 py-2 text-sm text-gray-500">Loading departments...</div>
                  ) : departments.length > 0 ? (
                    departments.map((department) => (
                      <Link
                        key={department.id}
                        to={`/departments/${department.id}/products`}
                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-blue-600 transition-colors duration-200"
                        onClick={() => setShowDepartments(false)}
                      >
                        {department.name}
                      </Link>
                    ))
                  ) : (
                    <div className="px-4 py-2 text-sm text-gray-500">No departments available</div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Overlay to close dropdown when clicking outside */}
      {showDepartments && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowDepartments(false)}
        ></div>
      )}
    </nav>
  );
};

export default Navigation;