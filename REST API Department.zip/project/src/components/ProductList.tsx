import React, { useState, useEffect } from 'react';
import { Link, useParams, useLocation } from 'react-router-dom';
import { Eye, Search, ChevronLeft, ChevronRight, AlertCircle } from 'lucide-react';
import { fetchProducts, fetchDepartments, fetchProductsByDepartment, fetchProductsWithDepartment } from '../utils/api';

const ProductList = () => {
  const { departmentId } = useParams();
  const location = useLocation();
  const [products, setProducts] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [currentDepartment, setCurrentDepartment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [searchLoading, setSearchLoading] = useState(false);

  const loadProducts = async (page = 1, departmentFilter = '') => {
    setLoading(page === 1);
    setSearchLoading(page !== 1);
    setError(null);

    let result;
    
    if (departmentId) {
      // Fetch products for specific department using department ID
      result = await fetchProductsByDepartment(departmentId, page, 20);
    } else if (departmentFilter) {
      // Fetch products with department name filter
      result = await fetchProductsWithDepartment(page, 20, departmentFilter);
    } else {
      // Fetch all products
      result = await fetchProducts(page, 20);
    }
    
    const { data, error: fetchError } = result;
    
    if (fetchError) {
      setError(fetchError);
      setProducts([]);
    } else {
      setProducts(data?.products || []);
      setTotalPages(Math.ceil((data?.total || 0) / 20));
      setCurrentPage(page);
    }
    
    setLoading(false);
    setSearchLoading(false);
  };

  const loadDepartments = async () => {
    const { data, error: fetchError } = await fetchDepartments();
    if (!fetchError) {
      setDepartments(data);
      
      // Find current department if we're on a department page
      if (departmentId && data) {
        const dept = data.find(d => d.id.toString() === departmentId);
        setCurrentDepartment(dept);
      }
    }
  };

  useEffect(() => {
    // Reset state when route changes
    setCurrentPage(1);
    setSelectedDepartment('');
    setCurrentDepartment(null);
    
    loadProducts();
    loadDepartments();
  }, [departmentId, location.pathname]);

  const handleDepartmentChange = (departmentName) => {
    setSelectedDepartment(departmentName);
    setCurrentPage(1);
    loadProducts(1, departmentName);
  };

  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      if (departmentId) {
        loadProducts(page);
      } else {
        loadProducts(page, selectedDepartment);
      }
    }
  };

  const clearFilter = () => {
    setSelectedDepartment('');
    setCurrentPage(1);
    loadProducts(1, '');
  };
  const ProductCard = ({ product }) => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md hover:border-gray-300 transition-all duration-200 transform hover:-translate-y-1">
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-lg font-semibold text-gray-900 line-clamp-2 leading-tight">
            {product.name}
          </h3>
          <span className="text-2xl font-bold text-blue-600 ml-4 flex-shrink-0">
            ${product.retail_price}
          </span>
        </div>
        
        <div className="space-y-2 mb-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-500">Department</span>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
              {product.department || product.category}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-500">Brand</span>
            <span className="text-sm font-medium text-gray-900">{product.brand}</span>
          </div>
        </div>
        
        <Link
          to={`/products/${product.id}`}
          className="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
        >
          <Eye className="h-4 w-4 mr-2" />
          View Details
        </Link>
      </div>
    </div>
  );

  const LoadingSkeleton = () => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="p-6">
        <div className="animate-pulse">
          <div className="flex justify-between items-start mb-4">
            <div className="h-6 bg-gray-200 rounded w-3/4"></div>
            <div className="h-6 bg-gray-200 rounded w-16"></div>
          </div>
          <div className="space-y-2 mb-4">
            <div className="flex justify-between">
              <div className="h-4 bg-gray-200 rounded w-16"></div>
              <div className="h-4 bg-gray-200 rounded w-20"></div>
            </div>
            <div className="flex justify-between">
              <div className="h-4 bg-gray-200 rounded w-12"></div>
              <div className="h-4 bg-gray-200 rounded w-24"></div>
            </div>
          </div>
          <div className="h-10 bg-gray-200 rounded-lg"></div>
        </div>
      </div>
    </div>
  );

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Something went wrong</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <button
            onClick={() => loadProducts(currentPage, selectedDepartment)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {currentDepartment ? `${currentDepartment.name} Products` : 'Products'}
          </h1>
          <p className="text-gray-600">
            {currentDepartment 
              ? `Browse products in the ${currentDepartment.name} department`
              : 'Discover our complete product catalog'
            }
          </p>
        </div>

        {/* Search and Filter - Only show on main products page */}
        {!departmentId && (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 flex-1">
                <Search className="h-5 w-5 text-gray-400" />
                <select
                  value={selectedDepartment}
                  onChange={(e) => handleDepartmentChange(e.target.value)}
                  disabled={searchLoading}
                  className="flex-1 max-w-xs rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
                >
                  <option value="">All departments</option>
                  {departments.map((department) => (
                    <option key={department.id} value={department.name}>
                      {department.name}
                    </option>
                  ))}
                </select>
                {searchLoading && (
                  <div className="animate-spin rounded-full h-5 w-5 border-2 border-blue-600 border-t-transparent"></div>
                )}
              </div>
              {selectedDepartment && (
                <button
                  onClick={clearFilter}
                  className="ml-4 px-4 py-2 text-sm font-medium text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors duration-200"
                >
                  Clear Filter
                </button>
              )}
            </div>
          </div>
        )}

        {/* Products Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {[...Array(6)].map((_, index) => (
              <LoadingSkeleton key={index} />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-12">
            <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
            <p className="text-gray-500">
              {currentDepartment 
                ? `No products found in the ${currentDepartment.name} department.`
                : selectedDepartment
                ? `No products found in "${selectedDepartment}" department.`
                : 'No products are currently available.'
              }
            </p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between bg-white rounded-lg shadow-sm border border-gray-200 px-6 py-4">
                <div className="text-sm text-gray-700">
                  Page {currentPage} of {totalPages}
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 1 || searchLoading}
                    className="inline-flex items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages || searchLoading}
                    className="inline-flex items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default ProductList;