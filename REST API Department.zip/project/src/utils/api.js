const API_BASE_URL = 'http://127.0.0.1:5000';

// Generic API call function with error handling
const apiCall = async (endpoint) => {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    return { data, error: null };
  } catch (error) {
    console.error('API call failed:', error);
    return { 
      data: null, 
      error: error.message || 'An unexpected error occurred' 
    };
  }
};

// Fetch paginated products with optional category filter
export const fetchProducts = async (page = 1, limit = 20, category = '') => {
  let endpoint = `/products?page=${page}&limit=${limit}`;
  if (category) {
    endpoint += `&category=${encodeURIComponent(category)}`;
  }
  return apiCall(endpoint);
};

// Fetch single product by ID
export const fetchProductById = async (id) => {
  return apiCall(`/products/${id}`);
};

// Fetch all departments
export const fetchDepartments = async () => {
  return apiCall('/departments');
};

// Fetch products by department
export const fetchProductsByDepartment = async (departmentId, page = 1, limit = 20) => {
  return apiCall(`/departments/${departmentId}/products?page=${page}&limit=${limit}`);
};

// Fetch products with optional department filter
export const fetchProductsWithDepartment = async (page = 1, limit = 20, departmentName = '') => {
  let endpoint = `/products?page=${page}&limit=${limit}`;
  if (departmentName) {
    endpoint += `&department=${encodeURIComponent(departmentName)}`;
  }
  return apiCall(endpoint);
};